import React from 'react';
import './Detailsview.css';
import { Link } from 'react-router-dom';

function Details() {
    return(
       <div class="detailscontainer">
     
       <ul class="responsive-table">
         <li class="table-header">
           <div class="col col-1">First Name</div>
           <div class="col col-2">Contract Name</div>
           <div class="col col-3">ContractType</div>
           <div class="col col-4">Amount</div>
           <div class="col col-5">Start Date</div>
           <div class="col col-6">End Date</div>
           <div class="col col-7">Action</div>
         </li>
         <li class="table-row">
           <div class="col col-1" data-label="Job Id">Priyanka</div>
           <div class="col col-2" data-label="Customer Name">Lease Agreement</div>
           <div class="col col-3" data-label="Amount">Integrated Contract</div>
           <div class="col col-4" data-label="Payment Status">25,000</div>
           <div class="col col-5" data-label="Payment Status">14/04/2021</div>
           <div class="col col-6" data-label="Payment Status">25/09/2022</div>
           <div class="col col-7" data-label="Payment Status" ><Link to="/updateform">Edit</Link></div>
         </li>
         <li class="table-row">
           <div class="col col-1" data-label="Job Id">Priyanka</div>
           <div class="col col-2" data-label="Customer Name">Lease Agreement</div>
           <div class="col col-3" data-label="Amount">Integrated Contract</div>
           <div class="col col-4" data-label="Payment Status">25,000</div>
           <div class="col col-5" data-label="Payment Status">14/04/2021</div>
           <div class="col col-6" data-label="Payment Status">25/09/2022</div>
           <div class="col col-7" data-label="Payment Status" ><Link to="/updateform">Edit</Link></div>
         </li>
     
       </ul>
     </div>
     
  
    
    );
}
export default Details;