import React from 'react';
import './Registration Form.css';

/* import { Link } from 'react-router-dom'; */
function Form() {
    return(
      <div>
      <div className="formbdy">
<div class="container">    
    <div class="title">Registration</div>
    <div class="content">
      <form action="#">
        <div class="user-details">
          <div class="input-box">
            <span class="details">First Name</span>
            <input type="text" placeholder="first name" required/>
          </div>
          <div class="input-box">
            <span class="details">Last Name</span>
            <input type="text" placeholder="last name" required/>
          </div>
          <div class="input-box">
            <span class="details">Gender</span>
            <input type="text" placeholder="gender" required/>
          </div>
          <div class="input-box">
            <span class="details">Parties</span>
            <input type="text" placeholder="parties" required/>
          </div>
          <div class="input-box">
            <span class="details">Email</span>
            <input type="text" placeholder="email" required/>
          </div>

          <div class="input-box">
            <span class="details">Mobile</span>
            <input type="text" placeholder="mobile" required/>
          </div>

          <div class="input-box">
            <span class="details">Contract Name</span>
            <input type="text" placeholder="contract name" required/>
          </div>
          
          <div class="input-box">
            <span class="details">Contract Type</span>
            <select>
                <option value="select">Contract Type</option>
                <option value="Insurance">Insurance</option>
                <option value="Utilities">Utilities</option>
                <option value="Entertainment">Entertainment</option>
                <option value="Grooming">Grooming</option>
                <option value="Food">Food</option>
                <option value="Shopping">Shopping</option>
                <option value="HealthCare">HealthCare</option>
    
              </select>
        
          </div>

         
          <div class="input-box">
            <span class="details">Company Name</span>
            <input type="text" placeholder="company name" required/>
          </div>

          
          <div class="input-box">
            <span class="details">Department</span>
            <input type="text" placeholder="department" required/>
          </div>

         
          <div class="input-box">
            <span class="details">Start Date</span>
            <input type="date" placeholder="date" required/>
          </div>

         
          <div class="input-box">
            <span class="details">End Date</span>
            <input type="date" placeholder="date" required/>
          </div>

          <div class="input-box">
            <span class="details">Amount</span>
            <input type="text" placeholder="amount" required/>
          </div>

          <div class="input-box">
            <span class="details">File Upload</span>
            <input type="file" placeholder="Choose File" required/>
          </div>

          <div class="input-box">
            <span class="details">Address</span>
            <textarea placeholder="address" required></textarea>
          </div>
          <div class="input-box">
            <span class="details">Description</span>
            <textarea placeholder="description" required></textarea>

          </div>
      
       

        <div class="button">
            <input type="submit" value="Save"/>
            
          </div>
          
        <div class="button">
            <input type="submit" value="Save"/>
            
          </div>
        </div>
        </form>
      
      </div>
    </div>
    </div>

    </div>  
    );
}
export default Form;