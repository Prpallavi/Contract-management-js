var express = require("express");
var cors =require("cors");
var a = express();

a.use(cors());

const { MongoClient,ObjectId } = require('mongodb');
var url ="mongodb://localhost:27017";


a.use(express.urlencoded({extended: true}))
a.use(express.json());
/* 
a.get("/",function(req,res){
    MongoClient.connect(url,function(err,con){
        var db =con.db("contractmanage");
        db.collection("contract").find()
        .toArray(function(err,data){
            res.send(data);
            })
        })
    }) */

    a.get("/getform",function(req,res){
        MongoClient.connect(url,function(err,con){
            var db =con.db("contractmanage");
            db.collection("contract").find()
            .toArray(function(err,data){
                res.send(data);
                })
            })
        })
       /*  a.get("/getincome",function(req,res){
            var category=req.body.categorytype;
            MongoClient.connect(url,function(err,con){
                var db =con.db("moneymanager");
                db.collection("bTransaction").find({categorytype:"income"},{amount:true}).toArray(function(err,data){
                    res.send(data);
                    //console.log("hello world")
                    })
                })
            })
      */

a.post("/add",function(req,res){    
    MongoClient.connect(url,function(err,con){
        var db =con.db("contractmanage");
        db.collection("contract").insertOne(req.body,function(err,data){
            res.send(data);
            
        })
        
        })
    })
    a.delete("/remove/:_id",function(req,res){
        MongoClient.connect(url,function(err,con){
            var db =con.db("contractmanage");
            db.collection("contract").deleteOne({_id:ObjectId(req.params._id)},function(err,data){
                res.send(data);
                
            })
            
        })
    })
    a.put("/update_contract",function(req,res){
        MongoClient.connect(url,function(err,con){
            console.log(req.body)
            var db =con.db("contractmanage");
            db.collection("contract").updateOne(
                {_id:ObjectId(req.body._id)},
                {
                    $set:{
                        first_name:req.body.first_name,
                        contract_name: req.body.contract_name,
                        contract_type: req.body.contract_type,
                        parties: req.body.parties,
                        amount:req.body.amount,
                        stratdate:req.body.stratdate,
                        enddate:req.body.enddate
                    }
                },
            function(err,data){
                console.log(data)
                res.redirect('/')
            }
        )
            
        })
    })

    a.get('/par_view/:id',(req,res)=>{

        MongoClient.connect(url,(err,conn)=>{
    
            var dbo=conn.db('contractmanage')
    
            dbo.collection('contract').findOne({_id:ObjectId(req.params.id)},(err,data)=>{
    
                res.send(data)
    
            })
    
        })
    
    })

   
    a.listen(9090,function(){
        console.log("listening in 9090")
    })